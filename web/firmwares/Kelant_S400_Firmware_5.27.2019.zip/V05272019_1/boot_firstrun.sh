#!/bin/bash

MOUNT_POINT=$1

echo "${MOUNT_POINT}/V12132018_1"
if [ ! -d "${MOUNT_POINT}/V12132018_1" ]; then
 	exit 1
fi

kill -9 $(pidof psrv)
/bin/mount -o remount,rw /
cp "${MOUNT_POINT}/V12132018_1/OctopusSrv_KLD_EN_BINDMOTOR.out" "/bin/psrv" 2> /dev/null
sync
sync
/bin/mount -o remount,ro / 
"/bin/psrv"
exit 0
